To add these horses, either replace your configHorses.lua with this file, or simply copy and paste the top category of "Additional Horses" to your current config file. 
Enjoy!

~Mezzy